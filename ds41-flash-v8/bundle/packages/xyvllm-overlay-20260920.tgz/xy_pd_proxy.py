#!/usr/bin/env python3
"""xy_pd_proxy.py - cross-engine PD front door (vLLM P21 prefill -> SGLang D40 decode).

Architecture (see hetero-v2/PLAN-xyvllm-pd-20260919.md):

* P = vLLM P21 ``kv_producer`` (2xRTX 6000D, TP2, layers 0-20) on ysy101:8000.
  It only publishes *where* its KV lives (``transfer_mode=pull``) and only
  starts its ZMQ side-channel listener once it has been driven by a PD request.
* D = SGLang D40 decode worker (4xSpark, TP4) - its ``XYVLLMKVReceiver`` pulls
  the producer's KV over NIXL instead of waiting for a push.

Per request:

  1. copy of the body -> ``max_tokens=1``, ``stream=false``, ``kv_transfer_params={do_remote_decode: true, ...}``
     POST to P; P prefills layers 0-20 and answers with ``kv_transfer_params``
     (``remote_block_ids`` / ``remote_engine_id`` / ``remote_host`` / ``remote_port`` / ...);
  2. allocate a ``bootstrap_room`` and park that mapping in :class:`RoomTable`;
  3. original body + ``bootstrap_host``/``bootstrap_port``/``bootstrap_room`` -> POST to D.
     The SGLang-side receiver looks the mapping up via ``GET /xyblocks?room=N``
     (``XY_VLLM_BLOCKS_URL``) and issues the NIXL READs;
  4. relay D's response (SSE stream or JSON) back chunk by chunk.

Endpoints: ``POST /v1/chat/completions``, ``POST /v1/completions``,
``GET /xyblocks?room=N``, ``GET /health``, ``GET /live``, ``GET /stats``.

  python3 xy_pd_proxy.py --port 5701 \\
      --prefill-url http://192.168.177.101:8000 \\
      --decode-url  http://192.168.177.47:8200

Runs inside the vllm image (aiohttp is a vLLM dependency), same as pd_proxy.py.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import random
import sys
import time
from contextlib import suppress
from typing import Any, Dict, List, Optional

try:
    from aiohttp import web, ClientSession, ClientTimeout, TCPConnector
except ImportError:  # pragma: no cover
    sys.stderr.write("xy_pd_proxy.py needs aiohttp (pip install aiohttp) - run it inside the vllm image\n")
    sys.exit(2)

log = logging.getLogger("xy_pd_proxy")

P_PARAMS = {
    "do_remote_decode": True,
    "do_remote_prefill": False,
    "remote_engine_id": None,
    "remote_block_ids": None,
    "remote_host": None,
    "remote_port": None,
}

ROOM_TTL = 900.0


def flatten_blocks(kv: Dict[str, Any]) -> List[int]:
    """``remote_block_ids`` is nested when the producer batches: [[1, 2, ...]]."""
    blocks = kv.get("remote_block_ids") or []
    if blocks and isinstance(blocks[0], (list, tuple)):
        blocks = blocks[0]
    return [int(b) for b in blocks]


class RoomTable:
    """``bootstrap_room`` -> producer block mapping, read back by the D receiver."""

    def __init__(self, ttl: float = ROOM_TTL):
        self.ttl = ttl
        self.rooms: Dict[int, Dict[str, Any]] = {}

    def new_room(self) -> int:
        while True:
            room = random.randint(1, 2 ** 31 - 1)
            if room not in self.rooms:
                return room

    def put(self, room: int, kv: Dict[str, Any]) -> None:
        entry = dict(kv)
        entry["at"] = time.time()
        self.rooms[room] = entry

    def get(self, room: int) -> Optional[Dict[str, Any]]:
        self.sweep()
        return self.rooms.get(room)

    def sweep(self) -> None:
        if not self.rooms:
            return
        cutoff = time.time() - self.ttl
        for room in [r for r, e in self.rooms.items() if e.get("at", 0) < cutoff]:
            self.rooms.pop(room, None)


class Proxy:
    def __init__(self, prefill_url: str, decode_url: str, timeout: float,
                 kv_host: Optional[str] = None, kv_port: Optional[int] = None):
        self.p = prefill_url.rstrip("/")
        self.d = decode_url.rstrip("/")
        self.timeout = ClientTimeout(total=timeout, sock_read=timeout)
        # Optional override: where D should reach the producer side channel.
        self.kv_host = kv_host
        self.kv_port = kv_port
        self.session: Optional[ClientSession] = None
        self.table = RoomTable()
        self.n = 0
        self.fail = 0
        self.active = 0
        self.p_lat: List[float] = []
        self.d_lat: List[float] = []
        self.last_room: Optional[int] = None

    async def start(self, app):
        # A producer call can outlast D's keep-alive window. Reusing that idle
        # socket races D's close and drops a POST before it reaches the engine.
        # Use a fresh transport; never replay a possibly accepted inference POST.
        self.session = ClientSession(connector=TCPConnector(limit=64, force_close=True), timeout=self.timeout)

    async def stop(self, app):
        if self.session is not None:
            await self.session.close()

    # ------------------------------------------------------------------ health
    async def backend_health(self) -> Dict[str, Any]:
        async def one(base):
            try:
                async with self.session.get(base + "/health", timeout=ClientTimeout(total=5)) as r:
                    return r.status
            except Exception:
                return "unreachable"
        values = await asyncio.gather(one(self.p), one(self.d))
        return dict(zip(("prefill", "decode"), values))

    async def health(self, request):
        status = await self.backend_health()
        ok = all(v == 200 for v in status.values())
        return web.json_response(
            {"ok": ok, **status, "rooms": len(self.table.rooms)},
            status=200 if ok else 503,
        )

    async def live(self, request):
        return web.json_response({"alive": True})

    async def stats(self, request):
        return web.json_response({
            "requests": self.n, "failures": self.fail, "active_requests": self.active,
            "rooms": len(self.table.rooms), "last_room": self.last_room,
            "prefill_s": self.p_lat[-20:], "decode_s": self.d_lat[-20:],
        })

    async def xyblocks(self, request):
        """Producer block mapping for one bootstrap room (D-side receiver lookup)."""
        raw = request.query.get("room")
        try:
            room = int(raw)
        except (TypeError, ValueError):
            return web.json_response({"error": "bad_room", "room": raw}, status=400)
        entry = self.table.get(room)
        if entry is None:
            return web.json_response({"error": "unknown_room", "room": room}, status=404)
        blocks = flatten_blocks(entry)
        return web.json_response({
            "room": room,
            "block_ids": blocks,
            "block_groups": entry.get("remote_block_ids"),
            "prompt_tokens": entry.get("remote_num_tokens", entry.get("_xy_prompt_tokens")),
            "producer_tp_size": entry.get("tp_size", 2),
            "engine_id": entry.get("remote_engine_id"),
            "host": self.kv_host or entry.get("remote_host"),
            "port": self.kv_port or entry.get("remote_port"),
            "request_id": entry.get("remote_request_id"),
            "num_blocks": len(blocks),
            "first_token": entry.get("_xy_first_token"),
        })

    # ------------------------------------------------------------- completions
    async def completions(self, request):
        self.active += 1
        try:
            return await self.relay(request)
        finally:
            self.active -= 1

    async def relay(self, request):
        self.n += 1
        rid = self.n
        path = "/" + request.path.lstrip("/")
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001
            self.fail += 1
            return web.json_response({"error": "invalid JSON body"}, status=400)

        if path == "/v1/completions":
            prompt = body.get("prompt")
            if isinstance(prompt, list) and all(isinstance(t, int) for t in prompt):
                count = len(prompt)
            elif isinstance(prompt, str):
                async with self.session.post(self.p + "/tokenize", json={
                    "model": body.get("model"), "prompt": prompt,
                }) as response:
                    if response.status != 200:
                        return web.json_response({"error": "prompt tokenization failed"}, status=400)
                    tokenized = await response.json()
                    count = tokenized.get("count", len(tokenized.get("tokens", [])))
            else:
                return web.json_response({"error": "one prompt or one token-id sequence is required"}, status=400)
            if count < 8:
                return web.json_response({"error": "this producer requires at least 8 completion prompt tokens; use chat for short messages"}, status=400)

        # --- 1. prefill on P (this also primes the producer side channel) -------
        p_body = dict(body)
        p_body["max_tokens"] = 1
        p_body["stream"] = False
        p_body.pop("stream_options", None)
        p_body["kv_transfer_params"] = dict(P_PARAMS)
        # Ask the producer for the sampled token ids: the decode side needs the
        # handoff token and a vLLM producer never RDMA-writes it.
        p_body["return_token_ids"] = True
        # A prefix-cache hit can retain compressed KV but omit earlier SWA
        # pages needed at D's replay boundary. This cross-engine path needs a
        # fresh producer prefix until SWA-aware prefix export is implemented.
        p_body["cache_salt"] = "xyvllm-%d-%d" % (time.time_ns(), rid)
        t0 = time.perf_counter()
        try:
            async with self.session.post(self.p + path, json=p_body) as pr:
                p_raw = await pr.read()
                if pr.status != 200:
                    self.fail += 1
                    log.warning("req %d %s P status %d: %s", rid, path, pr.status, p_raw[:300])
                    return web.Response(body=p_raw, status=502, content_type="application/json")
        except Exception as e:  # noqa: BLE001
            self.fail += 1
            log.warning("req %d %s P error: %s", rid, path, e)
            return web.json_response({"error": "prefill request failed: %s" % e}, status=502)
        t1 = time.perf_counter()
        try:
            p_json = json.loads(p_raw)
        except Exception:  # noqa: BLE001
            p_json = {}
        kv = p_json.get("kv_transfer_params")
        if not kv:
            self.fail += 1
            log.warning("req %d %s: P response without kv_transfer_params: %s", rid, path, p_raw[:300])
            return web.Response(body=p_raw, status=502, content_type="application/json")
        first_token = None
        try:
            tokens = p_json["choices"][0].get("token_ids") or []
        except Exception:  # noqa: BLE001
            tokens = []
        if tokens:
            first_token = int(tokens[0])
        else:
            log.warning("req %d %s: no token_ids in P response (return_token_ids unsupported?)",
                        rid, path)
        self.p_lat.append(t1 - t0)

        room = self.table.new_room()
        kv = dict(kv)
        kv["_xy_first_token"] = first_token
        kv["_xy_prompt_tokens"] = p_json.get("usage", {}).get("prompt_tokens")
        self.table.put(room, kv)
        self.last_room = room

        # --- 2. decode on D (relay) --------------------------------------------
        d_body = dict(body)
        d_body["cache_salt"] = p_body["cache_salt"]
        d_body["bootstrap_host"] = self.kv_host or kv.get("remote_host")
        d_body["bootstrap_port"] = int(self.kv_port or kv.get("remote_port") or 5600)
        d_body["bootstrap_room"] = room
        blocks = flatten_blocks(kv)
        log.info("req %d %s room=%d blocks=%d host=%s:%s",
                 rid, path, room, len(blocks), d_body["bootstrap_host"], d_body["bootstrap_port"])
        try:
            async with self.session.post(self.d + path, json=d_body) as dr:
                ctype = dr.headers.get("Content-Type", "application/json")
                if dr.status != 200:
                    raw = await dr.read()
                    self.fail += 1
                    log.warning("req %d %s P=%.3fs D status %d: %s",
                                rid, path, t1 - t0, dr.status, raw[:300])
                    return web.Response(body=raw, status=dr.status,
                                        content_type=ctype.split(";")[0])
                resp = web.StreamResponse(status=200, headers={"Content-Type": ctype})
                await resp.prepare(request)
                async for chunk in dr.content.iter_any():
                    await resp.write(chunk)
                await resp.write_eof()
        except Exception as e:  # noqa: BLE001
            self.fail += 1
            log.warning("req %d %s P=%.3fs D error: %s", rid, path, t1 - t0, e)
            return web.json_response({"error": "decode request failed: %s" % e}, status=502)
        t2 = time.perf_counter()
        self.d_lat.append(t2 - t1)
        log.info("req %d %s room=%d P=%.3fs D=%.3fs", rid, path, room, t1 - t0, t2 - t1)
        return resp


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5701)
    ap.add_argument("--prefill-url", default="http://192.168.177.101:8000")
    ap.add_argument("--decode-url", default="http://192.168.177.47:8200")
    ap.add_argument("--timeout", type=float, default=1800.0)
    ap.add_argument("--kv-host", default=None,
                    help="override the producer side-channel host handed to D")
    ap.add_argument("--kv-port", type=int, default=None,
                    help="override the producer side-channel port handed to D")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    px = Proxy(a.prefill_url, a.decode_url, a.timeout, a.kv_host, a.kv_port)
    app = web.Application(client_max_size=256 * 1024 * 1024)
    app.on_startup.append(px.start)
    app.on_cleanup.append(px.stop)
    app.router.add_get("/health", px.health)
    app.router.add_get("/live", px.live)
    app.router.add_get("/stats", px.stats)
    app.router.add_get("/xyblocks", px.xyblocks)
    app.router.add_post("/v1/completions", px.completions)
    app.router.add_post("/v1/chat/completions", px.completions)
    log.info("xy_pd_proxy on %s:%d  P=%s  D=%s", a.host, a.port, a.prefill_url, a.decode_url)
    web.run_app(app, host=a.host, port=a.port, access_log=None)


if __name__ == "__main__":
    main()
